#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>

#define SERVER_PATH "/home/z/my-project/mini-server"

int main() {
    signal(SIGPIPE, SIG_IGN);
    
    while (1) {
        pid_t pid = fork();
        if (pid == 0) {
            // Child: exec the server
            execl(SERVER_PATH, "mini-server", NULL);
            _exit(1);
        } else if (pid > 0) {
            // Parent: wait for child to die, then restart
            int status;
            waitpid(pid, &status, 0);
            fprintf(stderr, "Server (PID %d) exited, restarting in 1s...\n", pid);
            sleep(1);
        } else {
            perror("fork");
            sleep(5);
        }
    }
    return 0;
}
