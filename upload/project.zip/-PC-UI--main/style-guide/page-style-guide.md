# Page Style Guide - Agent Management System

## 1. Overall Layout Structure
- **Left Sidebar Navigation**: Fixed-width sidebar with Logo and navigation menu
- **Top Navigation Bar**: Page title, record count, notification icon, language switch, user info
- **Main Content Area**: Statistics cards area, filter area, data table area
- **Layout Pattern**: Classic left sidebar + main content two-column layout

## 2. Color Scheme
- **Primary Color**: Blue (#3B82F6) - for buttons, links, selected states
- **Secondary Colors**:
  - Green (#10B981) - for "Active" status and success indicators
  - Yellow/Amber (#F59E0B) - for "Abnormal" status and warnings
  - Red (#EF4444) - for "Disabled" status and alerts
  - Purple (#8B5CF6) - for level/tag labels
- **Background Colors**:
  - Main background: #F9FAFB (light gray)
  - Card background: #FFFFFF (white)
  - Sidebar background: #FFFFFF (white)
- **Text Colors**:
  - Primary title: #111827 (dark gray)
  - Secondary text: #6B7280 (gray)
  - Auxiliary text: #9CA3AF (light gray)

## 3. Typography
- **Font Family**: Sans-serif (Inter, Arial, sans-serif)
- **Title Font**:
  - Page title: 16px, weight 600
  - Card title: 12px, weight 500, uppercase
- **Body Font**:
  - Table content: 14px, weight 400
  - Navigation menu: 14px, weight 400
- **Special Font**:
  - Status label: 12px, weight 500

## 4. Card/Component Styles
- **Border Radius**: 8px (all cards and containers)
- **Shadow**: Light shadow (box-shadow: 0 1px 3px rgba(0,0,0,0.05))
- **Border**: None, light separation between cards
- **Padding**:
  - Card padding: 20px 24px
  - Table padding: 16px
- **Card Layout**: 4-column grid, each column 25% width

## 5. Button Styles
- **Border Radius**: 6px
- **Primary Button** (Blue):
  - Background: #3B82F6
  - Text: #FFFFFF
  - Hover: Background changes to #2563EB
- **Secondary Button** (White with border):
  - Border: 1px solid #D1D5DB
  - Text: #6B7280
  - Hover: Border changes to #3B82F6, text changes to #3B82F6
- **Button Size**: 32px height, padding: 0 16px

## 6. Spacing and Alignment
- **Margins**:
  - Page margin: 16px
  - Card gap: 16px
  - Table row gap: 8px
- **Padding**:
  - Card padding: 24px
  - Table cell padding: 12px 16px
- **Alignment**:
  - Text: left-aligned
  - Numbers: right-aligned
  - Action buttons: right-aligned

## 7. Icons and Decorative Elements
- **Icon Style**: Linear/outline icons, minimalist design
- **Icon Colors**:
  - Blue: #3B82F6
  - Green: #10B981
  - Yellow: #F59E0B
  - Red: #EF4444
- **Status Indicators**: Small dots matching status color

## 8. Special Design Details
- **Breadcrumb Navigation**: Shows current path (Dashboard > Agents)
- **Filter Area**: Multiple input boxes and dropdown menus, action buttons on the right
- **Data Table**:
  - Fixed header
  - Selectable rows (checkboxes)
  - Status labels with different colors
  - Action column with buttons and more options
- **Responsive Design**: Layout adjusts for smaller screens
- **User Avatar**: Circular, showing user initials

## Design Philosophy
Modern, clean interface style emphasizing clear information display and convenient operations, suitable for management system scenarios.
